import com.google.gson.annotations.SerializedName
import sankovskij.api.testappfortfn.devices.model.Device

data class DeviceData (
	@field:SerializedName("data") val data : Device
)