package sankovskij.api.testappfortfn.devices.retrofit

import DeviceList
import retrofit2.Call
import retrofit2.http.GET

interface DevicesAPI {
    @GET("api/v1.1/test/devices")
    fun getDevices(): Call<DeviceList>
}
