package sankovskij.api.testappfortfn.devices.retrofit

import DeviceList
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path

interface DeviceAPI {
    @GET("api/v1/test/devices/{id}")
    fun loadDevice(@Path("id") id: Int?): Call<DeviceList>}
