package sankovskij.api.testappfortfn.main.presenter

import moxy.MvpPresenter
import sankovskij.api.testappfortfn.main.view.MainView

class MainPresenter(): MvpPresenter<MainView>() {


}