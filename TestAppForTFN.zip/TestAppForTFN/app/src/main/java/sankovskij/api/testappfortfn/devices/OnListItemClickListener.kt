package sankovskij.api.testappfortfn.devices

import sankovskij.api.testappfortfn.devices.model.Device

interface OnListItemClickListener {
        fun onItemClick(device: Device)
    }
