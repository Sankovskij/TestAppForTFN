package sankovskij.api.testappfortfn.devices.presenter

import DeviceList
import moxy.InjectViewState
import moxy.MvpPresenter
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import sankovskij.api.testappfortfn.devices.DevicesView
import sankovskij.api.testappfortfn.devices.retrofit.DevicesRetrofit

@InjectViewState
class DevicesPresenter(private val deviceRetrofit: DevicesRetrofit = DevicesRetrofit()) : MvpPresenter<DevicesView>() {

    override fun onFirstViewAttach() {
        super.onFirstViewAttach()
        viewState.init()
        sendServerRequest()
    }


    private fun sendServerRequest() {
        deviceRetrofit.getRetrofitImpl().getDevices().enqueue(object :
            Callback<DeviceList> {
            override fun onResponse(call: Call<DeviceList>, response: Response<DeviceList>) {
                if (response.isSuccessful && response.body() != null) {
                    viewState.updateRV(response.body()!!)
                }
            }

            override fun onFailure(call: Call<DeviceList>, t: Throwable) {
                //ошибка с кнопкой
            }
        }
        )
    }
}
