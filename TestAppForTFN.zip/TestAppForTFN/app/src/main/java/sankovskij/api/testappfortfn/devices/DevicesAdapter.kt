package sankovskij.api.testappfortfn.devices

import DeviceList
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.item_device.view.*
import sankovskij.api.testappfortfn.R
import sankovskij.api.testappfortfn.devices.model.Device

class DevicesAdapter(
    val onItemClick: ((Device) -> Unit)? = null
) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var data: DeviceList = DeviceList(
        listOf(
            Device(0, "", "", false, 0, "", 0),
            Device(0, "", "", false, 0, "", 0),
            Device(0, "", "", false, 0, "", 0)
        )
    )
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return if (viewType == TYPE_DEVICE) {
            DeviceViewHolder(
                inflater.inflate(R.layout.item_device, parent, false) as View
            )

        } else {
            LoadingViewHolder(
                inflater.inflate(R.layout.item_loading, parent, false) as View
            )
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (getItemViewType(position) == TYPE_DEVICE) {
            holder as DeviceViewHolder
            holder.bind(data.devicesList[position])
        } else {
            holder as LoadingViewHolder
            holder.bind(data.devicesList[position])
        }
    }

    override fun getItemCount(): Int {
        return data.devicesList.size
    }

    override fun getItemViewType(position: Int): Int {
        return if (data.devicesList[position].name.isNullOrBlank()) TYPE_LOADING else TYPE_DEVICE
    }

    inner class LoadingViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        fun bind(device: Device) {
        }
    }


    inner class DeviceViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        fun bind(device: Device) {
            if (layoutPosition != RecyclerView.NO_POSITION) {
                if (device.isOnline) {
                    itemView.online_offline.text = "ON LINE"
                } else {
                    itemView.online_offline.text = "OFF LINE"
                }
                itemView.device_name.text = device.name
                when (device.status) {
                    "1" -> {
                        itemView.status.text = "ГАЗ НЕ ОБНАРУЖЕН"
                    }
                    "2" -> {
                        itemView.status.text = "ГАЗ ОБНАРУЖЕН"
                    }
                    else -> {
                        itemView.status.text = device.status
                    }
                }
                if (device.type == 1) {
                    itemView.time.text = device.lastWorkTime.toString()
                    itemView.device_imageView.setImageResource(R.drawable.device1)
                } else {
                    itemView.time.isVisible = false
                    itemView.device_imageView.setImageResource(R.drawable.device2)
                }
                itemView.item_layout.setOnClickListener { onItemClick?.invoke(device) }
            }
        }
    }
    companion object {
        private const val TYPE_LOADING = 0
        private const val TYPE_DEVICE = 1
    }
}
