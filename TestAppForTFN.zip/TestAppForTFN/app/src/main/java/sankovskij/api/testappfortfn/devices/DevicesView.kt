package sankovskij.api.testappfortfn.devices

import DeviceList
import moxy.MvpView
import moxy.viewstate.strategy.AddToEndSingleStrategy
import moxy.viewstate.strategy.StateStrategyType

@StateStrategyType(AddToEndSingleStrategy::class)
interface DevicesView : MvpView {
    fun init()
    fun updateRV(deviceList: DeviceList)

}