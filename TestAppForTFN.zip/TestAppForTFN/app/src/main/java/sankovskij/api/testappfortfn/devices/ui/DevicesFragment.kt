package sankovskij.api.testappfortfn.devices.ui

import DeviceList
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import kotlinx.android.synthetic.main.fragment_device.*
import moxy.MvpAppCompatFragment
import moxy.ktx.moxyPresenter
import sankovskij.api.testappfortfn.App
import sankovskij.api.testappfortfn.R
import sankovskij.api.testappfortfn.devices.DevicesAdapter
import sankovskij.api.testappfortfn.devices.DevicesView
import sankovskij.api.testappfortfn.devices.presenter.DevicesPresenter

class DevicesFragment : MvpAppCompatFragment(), DevicesView {

    lateinit var adapter: DevicesAdapter

    val presenter: DevicesPresenter by moxyPresenter { DevicesPresenter().apply {
        App.instance.appComponent.inject(this)
    }}

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        App.instance.appComponent.inject(this)
        return View.inflate(context, R.layout.fragment_device, null)
    }

    override fun init() {
        rv_devices.layoutManager = GridLayoutManager(context, 1)
        adapter = DevicesAdapter{
            //удаление
            //фрагмент диалог
        }
        rv_devices.adapter = adapter
    }

    override fun updateRV(deviceList: DeviceList) {
        adapter.data = deviceList
    }

}