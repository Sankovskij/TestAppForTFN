import com.google.gson.annotations.SerializedName
import sankovskij.api.testappfortfn.devices.model.Device

data class DeviceList (
	@field:SerializedName("data") val devicesList : List<Device>
)